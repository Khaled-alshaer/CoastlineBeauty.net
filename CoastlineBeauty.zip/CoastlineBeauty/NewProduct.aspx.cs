﻿using Microsoft.AspNet.Identity;
using System;
using System.IO;
using System.Web;

public partial class NewProduct : System.Web.UI.Page
{
    Helpers help = new Helpers();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void submitButton_Click(object sender, EventArgs e)
    {
        Product product = new Product();
        product.Name = name.Text;
        product.Description = description.Text;
        product.Type = type.Text;
        product.Size = size.Text;
        product.Gender = gender.Text;
        //handles image
        product.Image = SaveImage(this.imageUpload.PostedFile);
        product.Manufacture = manufacture.Text;
        product.Cost = Convert.ToDecimal(cost.Text);
        product.Price = Convert.ToDecimal(price.Text);
        product.Quantity = Convert.ToInt16(quantity.Text);
        product.userid = User.Identity.GetUserId();



        help.createProduct(product);
        Response.Redirect($"inventory.aspx?uid={product.userid}");
    }

    private string SaveImage(HttpPostedFile image)
    {
        string fileName = Path.GetFileName(image.FileName);
        string folderPath = Server.MapPath("~/Images/");
        string imagePath = Path.Combine(folderPath, fileName);

        image.SaveAs(imagePath);

        return "~/Images/" + fileName;
    }
}