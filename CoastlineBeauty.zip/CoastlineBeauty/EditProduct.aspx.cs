﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using Microsoft.AspNet.Identity;

public partial class EditProduct : System.Web.UI.Page
{
    Helpers help = new Helpers();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string pid = Request.QueryString["pid"];
            LoadProducts(pid);
        }
    }

    private void LoadProducts(string pid)
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"SELECT * FROM Inventory where id = @prodID";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@prodID", pid);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        name.Text = reader["name"].ToString();
                        description.Text = reader["description"].ToString();
                        type.Text = reader["type"].ToString();
                        size.Text = reader["size"].ToString();
                        gender.Text = reader["gender"].ToString();
                        //handles image
                        prodImage.Src = reader["image"].ToString();
                        manufacture.Text = reader["name"].ToString(); ;
                        cost.Text = reader["cost"].ToString();
                        price.Text = reader["price"].ToString();
                        quantity.Text = reader["quantity"].ToString();
                        HiddenField1.Value = reader["id"].ToString();
                        HiddenField2.Value = reader["userid"].ToString();
                    }
                }
            }
        }
    }

    protected void submitButton_Click(object sender, EventArgs e)
    {
        Product product = new Product();
        product.Name = name.Text;
        product.Description = description.Text;
        product.Type = type.Text;
        product.Size = size.Text;
        product.Gender = gender.Text;
        product.Manufacture = manufacture.Text;
        product.Cost = Convert.ToDecimal(cost.Text);
        product.Price = Convert.ToDecimal(price.Text);
        product.Quantity = Convert.ToInt16(quantity.Text);
        product.ID = Convert.ToInt16(HiddenField1.Value);
        product.userid = HiddenField2.Value;



        help.editProduct(product);
        Response.Redirect($"inventory.aspx?uid={product.userid}");
    }
}