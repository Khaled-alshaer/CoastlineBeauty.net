﻿using Microsoft.AspNet.Identity;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class ProductDetails : System.Web.UI.Page
{
    Helpers help = new Helpers();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string pid = Request.QueryString["pid"];
            LoadProducts(pid);
        }
    }

    private void LoadProducts(string pid)
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"SELECT * FROM Inventory where id = @prodID";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@prodID", pid);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    this.productRepeater.DataSource = dataTable;
                    this.productRepeater.DataBind();
                }
            }
        }
    }

    protected void AddCartButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string pid = button.CommandArgument;
        string userId = User.Identity.GetUserId();
        help.AddToCart(userId, pid);

        Response.Redirect($"Cart.aspx?uid={userId}");
    }
}