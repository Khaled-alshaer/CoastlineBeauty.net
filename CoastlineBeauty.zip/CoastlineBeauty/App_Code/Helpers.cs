﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Helpers
/// </summary>
public class Helpers
{
    static string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
    Product product = new Product();

    public void createProduct(Product product)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"INSERT INTO Inventory (name, description, type, size, manufacture, gender, image, price, cost, quantity, userid) 
                            VALUES (@name, @description, @type, @size, @manufacture, @gender, @image, @price, @cost, @quantity, @userid)";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@name", product.Name);
                command.Parameters.AddWithValue("@description", product.Description);
                command.Parameters.AddWithValue("@type", product.Type);
                command.Parameters.AddWithValue("@size", product.Size);
                command.Parameters.AddWithValue("@manufacture", product.Manufacture);
                command.Parameters.AddWithValue("@Gender", product.Gender);
                command.Parameters.AddWithValue("@Image", product.Image);
                command.Parameters.AddWithValue("@Price", product.Price);
                command.Parameters.AddWithValue("@Cost", product.Cost);
                command.Parameters.AddWithValue("@Quantity", product.Quantity);
                command.Parameters.AddWithValue("@userid", product.userid);

                command.ExecuteNonQuery();

            }
        }
    }

    public void editProduct(Product product)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"UPDATE Inventory SET name = @name, description = @description, type = @type, size = @size, manufacture = @manufacture, 
                            gender = @gender, price = @price, cost = @cost, quantity = @quantity where id = @id";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@name", product.Name);
                command.Parameters.AddWithValue("@description", product.Description);
                command.Parameters.AddWithValue("@type", product.Type);
                command.Parameters.AddWithValue("@size", product.Size);
                command.Parameters.AddWithValue("@manufacture", product.Manufacture);
                command.Parameters.AddWithValue("@Gender", product.Gender);
                //command.Parameters.AddWithValue("@Image", product.Image);
                command.Parameters.AddWithValue("@Price", product.Price);
                command.Parameters.AddWithValue("@Cost", product.Cost);
                command.Parameters.AddWithValue("@Quantity", product.Quantity);
                command.Parameters.AddWithValue("@id", product.ID);

                command.ExecuteNonQuery();

            }
        }
    }

    public void AddToCart(string uid, string pid)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"INSERT INTO Cart (userid, productid) 
                            VALUES (@userid, @productid)";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@userid", uid);
                command.Parameters.AddWithValue("@productid", pid);

                command.ExecuteNonQuery();

            }
        }
    }

    public void DeleteInventory(string id)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"DELETE FROM Inventory where id = @id";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@id", id);

                command.ExecuteNonQuery();

            }
        }
    }

    public void DeleteCart(string id)
    {
        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"DELETE FROM Cart where id = @id";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@id", id);

                command.ExecuteNonQuery();

            }
        }
    }
}