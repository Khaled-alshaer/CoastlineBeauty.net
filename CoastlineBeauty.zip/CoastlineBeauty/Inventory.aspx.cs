﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Inventory : System.Web.UI.Page
{
    Helpers help = new Helpers();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string uid = Request.QueryString["uid"];
            LoadInventory(uid);
        }
    }

    private void LoadInventory(string uid)
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = @"SELECT * FROM inventory where userID = @uid";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@uid", uid);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    this.productRepeater.DataSource = dataTable;
                    this.productRepeater.DataBind();
                }
            }
        }
    }

    protected void DeleteButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string productId = button.CommandArgument;
        help.DeleteInventory(productId);

        Response.Redirect($"inventory.aspx?uid={User.Identity.GetUserId()}");
    }

    protected void EditButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string productId = button.CommandArgument;

        Response.Redirect($"editproduct.aspx?pid={productId}");
    }
}