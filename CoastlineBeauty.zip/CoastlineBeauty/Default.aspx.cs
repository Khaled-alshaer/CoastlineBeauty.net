﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadProducts();
        }
    }

    private void LoadProducts(string productName = null)
    {
        string con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        using (SqlConnection connection = new SqlConnection(con))
        {
            connection.Open();

            string sql = "";

            if (!string.IsNullOrEmpty(productName))
            {
                sql = @"SELECT image, Name, Description, Price, id FROM Inventory where name like '%" + productName + "%'";
            }
            else
            {
                sql = "SELECT image, Name, Description, Price, id FROM Inventory";
            }

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    this.productRepeater.DataSource = dataTable;
                    this.productRepeater.DataBind();
                }
            }
        }
    }

    protected void ViewProductButton_Click(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        string productId = button.CommandArgument;

        Response.Redirect($"Productdetails.aspx?pid={productId}");
    }

    protected void SearchButton_Click(object sender, EventArgs e)
    {
        string productName = SearchTextBox.Text;
        LoadProducts(productName);
    }
}